const Header = () => {
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/60 backdrop-blur-xl">
      <div className="container flex h-16 items-center justify-between">
        
        {/* Logo */}
        <a href="#top" className="flex items-center gap-3">
          <span className="h-2.5 w-2.5 rounded-full bg-white shadow-[0_0_12px_rgba(255,255,255,0.6)]" />
          <span className="text-sm font-semibold tracking-widest text-white/90">
            INTO THE
          </span>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden items-center gap-8 text-sm md:flex">
          <a
            className="text-white/60 transition-colors duration-200 hover:text-white"
            href="#services"
          >
            서비스
          </a>
          <a
            className="text-white/60 transition-colors duration-200 hover:text-white"
            href="#why"
          >
            왜 인투더
          </a>
          <a
            className="text-white/60 transition-colors duration-200 hover:text-white"
            href="#process"
          >
            개발 프로세스
          </a>
          <a
            className="text-white/60 transition-colors duration-200 hover:text-white"
            href="#contact"
          >
            문의
          </a>
        </nav>

        {/* Right CTA */}
        <div className="hidden md:flex items-center gap-3">
          <a
            className="rounded-full border border-white/15 bg-white/[0.04] px-4 py-2 text-xs font-medium text-white/70 transition hover:bg-white/[0.08] hover:text-white"
            href="#services"
          >
            서비스 보기
          </a>

          <a
            style={{color:'#000'}}
            className="rounded-full bg-white px-5 py-2 text-xs font-semibold  transition hover:opacity-90"
            href="#contact"
          >
            프로젝트 문의
          </a>
        </div>

      </div>
    </header>
  );
};

export default Header;
